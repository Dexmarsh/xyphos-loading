local MODE = MODE
MODE.name = "war"

local playstart
local ended

net.Receive("war_start", function()
    surface.PlaySound("gamemodes/xyphos_zcity_sounds")
    if wr and wr.RemoveFade then wr.RemoveFade() end
    playstart = true
    ended = nil
end)

local teams = {
    [0] = {
        objective = "Kill all germans",
        name = "a German",
        color1 = Color(180, 0, 0),
        color2 = Color(180, 0, 0)
    },
    [1] = {
        objective = "Kill all americans",
        name = "an American",
        color1 = Color(0, 180, 0),
        color2 = Color(0, 180, 0)
    },
}

surface.CreateFont("timer_Font2", {
    font = "Bahnschrift", 
    size = ScreenScale(12), 
    extended = true, 
    weight = 660,
    antialias = true,
    italic = false
})

function MODE:RenderScreenspaceEffects()
    if not wr or not wr.ROUND_START then return end
    if wr.ROUND_START + 7.5 < CurTime() then return end
    local fade = math.Clamp(wr.ROUND_START + 7.5 - CurTime(), 0, 1)
    surface.SetDrawColor(0, 0, 0, 255 * fade)
    surface.DrawRect(-1, -1, ScrW() + 1, ScrH() + 1)
end

function MODE:HUDPaint()
    if not wr or not wr.ROUND_START then return end
    if wr.ROUND_START + 8.5 < CurTime() then return end

    local lply = LocalPlayer()
    if not IsValid(lply) or not lply:Alive() then return end

    if wr.RemoveFade then wr.RemoveFade() end
    local fade = math.Clamp(wr.ROUND_START + 8 - CurTime(), 0, 1)
    local team_ = lply:Team()
    local sw, sh = ScrW(), ScrH()

    draw.SimpleText("You are going to war", "WR_HomicideMediumLarge", sw * 0.5, sh * 0.1, Color(0, 162, 255, 255 * fade), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    if teams[team_] then
        local Rolename = teams[team_].name
        local ColorRole = teams[team_].color1
        ColorRole.a = 255 * fade
        draw.SimpleText("You are " .. Rolename, "WR_HomicideMediumLarge", sw * 0.5, sh * 0.5, ColorRole, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        
        local Objective = teams[team_].objective
        local ColorObj = teams[team_].color2
        ColorObj.a = 255 * fade
        draw.SimpleText(Objective, "WR_HomicideMedium", sw * 0.5, sh * 0.9, ColorObj, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end

local CreateEndMenu
net.Receive("war_end", function()
    ended = true
    if CreateEndMenu then CreateEndMenu() end
end)

local colGray = Color(83, 83, 83, 255)
local colRed = Color(130, 10, 10)
local colRedUp = Color(160, 30, 30)
local colSpect1 = Color(75, 75, 75, 255)
local colSpect2 = Color(255, 255, 255)
local col = Color(255, 255, 255, 255)

BlurBackground = BlurBackground or (hg and hg.DrawBlur) or function() end

if IsValid(hmcdEndMenu) then
    hmcdEndMenu:Remove()
    hmcdEndMenu = nil
end

CreateEndMenu = function()
    if IsValid(hmcdEndMenu) then
        hmcdEndMenu:Remove()
        hmcdEndMenu = nil
    end

    hmcdEndMenu = vgui.Create("ZFrame")
    surface.PlaySound("ambient/alarms/warningbell1.wav")
    local sizeX, sizeY = ScrW() / 2.5, ScrH() / 1.2
    local posX, posY = ScrW() / 1.3 - sizeX / 2, ScrH() / 2 - sizeY / 2
    hmcdEndMenu:SetPos(posX, posY)
    hmcdEndMenu:SetSize(sizeX, sizeY)
    hmcdEndMenu:MakePopup()
    hmcdEndMenu:SetKeyboardInputEnabled(false)
    hmcdEndMenu:ShowCloseButton(false)

    local closebutton = vgui.Create("DButton", hmcdEndMenu)
    closebutton:SetPos(5, 5)
    closebutton:SetSize(ScrW() / 20, ScrH() / 30)
    closebutton:SetText("")
    closebutton.DoClick = function()
        if IsValid(hmcdEndMenu) then
            hmcdEndMenu:Close()
            hmcdEndMenu = nil
        end
    end

    closebutton.Paint = function(self, w, h)
        surface.SetDrawColor(122, 122, 122, 255)
        surface.DrawOutlinedRect(0, 0, w, h, 2.5)
        surface.SetFont("ZB_InterfaceMedium")
        surface.SetTextColor(col.r, col.g, col.b, col.a)
        local lengthX, lengthY = surface.GetTextSize("Close")
        surface.SetTextPos(lengthX - lengthX / 1.1, 4)
        surface.DrawText("Close")
    end

    hmcdEndMenu.Paint = function(self, w, h)
        BlurBackground(self)
        surface.SetFont("ZB_InterfaceMediumLarge")
        surface.SetTextColor(col.r, col.g, col.b, col.a)
        local lengthX, lengthY = surface.GetTextSize("Players:")
        surface.SetTextPos(w / 2 - lengthX / 2, 20)
        surface.DrawText("Players:")
        surface.SetDrawColor(255, 0, 0, 128)
        surface.DrawOutlinedRect(0, 0, w, h, 2.5)
    end

    local DScrollPanel = vgui.Create("DScrollPanel", hmcdEndMenu)
    DScrollPanel:SetPos(10, 80)
    DScrollPanel:SetSize(sizeX - 20, sizeY - 90)
    function DScrollPanel:Paint(w, h)
        BlurBackground(self)
        surface.SetDrawColor(255, 0, 0, 128)
        surface.DrawOutlinedRect(0, 0, w, h, 2.5)
    end

    for i, ply in player.Iterator() do
        if ply:Team() == TEAM_SPECTATOR then continue end
        local but = vgui.Create("DButton", DScrollPanel)
        but:SetSize(100, 50)
        but:Dock(TOP)
        but:DockMargin(8, 6, 8, -1)
        but:SetText("")
        but.Paint = function(self, w, h)
            local col1 = (ply:Alive() and colRed) or colGray
            local col2 = (ply:Alive() and colRedUp) or colSpect1
            surface.SetDrawColor(col1.r, col1.g, col1.b, col1.a)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(col2.r, col2.g, col2.b, col2.a)
            surface.DrawRect(0, h / 2, w, h / 2)
            
            local playerCol = ply:GetPlayerColor():ToColor()
            surface.SetFont("ZB_InterfaceMediumLarge")
            local lengthX, lengthY = surface.GetTextSize(ply:GetPlayerName() or "He quit...")
            
            surface.SetTextColor(0, 0, 0, 255)
            surface.SetTextPos(w / 2 + 1, h / 2 - lengthY / 2 + 1)
            surface.DrawText(ply:GetPlayerName() or "He quit...")
            
            surface.SetTextColor(playerCol.r, playerCol.g, playerCol.b, playerCol.a)
            surface.SetTextPos(w / 2, h / 2 - lengthY / 2)
            surface.DrawText(ply:GetPlayerName() or "He quit...")

            surface.SetTextColor(colSpect2.r, colSpect2.g, colSpect2.b, colSpect2.a)
            surface.SetTextPos(15, h / 2 - lengthY / 2)
            surface.DrawText((ply:Name() .. (not ply:Alive() and " - died" or "")) or "He quit...")

            local fragText = tostring(ply:Frags() or 0)
            local fragX, fragY = surface.GetTextSize(fragText)
            surface.SetTextPos(w - fragX - 15, h / 2 - fragY / 2)
            surface.DrawText(fragText)
        end

        function but:DoClick()
            if ply:IsBot() then
                chat.AddText(Color(255, 0, 0), "no, you can't")
                return
            end

            gui.OpenURL("https://steamcommunity.com/profiles/" .. ply:SteamID64())
        end

        DScrollPanel:AddItem(but)
    end
    return true
end

function MODE:RoundStart()
    if IsValid(hmcdEndMenu) then
        hmcdEndMenu:Remove()
        hmcdEndMenu = nil
    end
end