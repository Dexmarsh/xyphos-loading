zb = zb or {}
zb.Modes = zb.Modes or {}

local MODE = {}
MODE.name = "war"
MODE.PrintName = "War"

-- Register mode into the base table
zb.Modes["war"] = MODE
zb.CurrentMode = zb.CurrentMode or "default"