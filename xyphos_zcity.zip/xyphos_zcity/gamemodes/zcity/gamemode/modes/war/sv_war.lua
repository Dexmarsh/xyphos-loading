util.AddNetworkString("war_start")
util.AddNetworkString("war_end")
util.AddNetworkString("zcity_request_war_mode")

local MODE = MODE

MODE.name = "war"
MODE.PrintName = "War"
MODE.LootSpawn = false
MODE.GuiltDisabled = true
MODE.randomSpawns = true
MODE.OverideSpawnPos = true

MODE.ForBigMaps = false
MODE.Chance = 0.05

local germanWeapons = {
    {primary = "weapon_ak74", secondary = "weapon_makarov", attachments = {{"holo6"},{"holo4"},{"optic8"}}, ammo = 3, ammo2 = 2},
    {primary = "weapon_akm", secondary = "weapon_makarov", attachments = {{"holo6","supressor1"},{"holo4","laser1"}}, ammo = 3, ammo2 = 2},
    {primary = "weapon_sks", secondary = "weapon_makarov", attachments = {{"optic8"},{"holo6"}}, ammo = 4, ammo2 = 2}
}

local americanWeapons = {
    {primary = "weapon_m4a1", secondary = "weapon_m1911", attachments = {{"holo1","grip1","supressor2"},{"laser4","grip2"}}, ammo = 3, ammo2 = 2},
    {primary = "weapon_hk416", secondary = "weapon_cz75", attachments = {{"holo1","grip1"},{"holo5","grip3"}}, ammo = 3, ammo2 = 2},
    {primary = "weapon_ar15", secondary = "weapon_glock17", attachments = {{"holo1","grip1","supressor2"}}, ammo = 3, ammo2 = 2}
}

local germanArmor = {"vest1", "helmet1"}
local americanArmor = {"vest3", "helmet1"}

local randomGrenades = {"weapon_hg_rgd_tpik", "weapon_hg_pipebomb_tpik", "weapon_hg_smokenade_tpik", "weapon_hg_flashbang_tpik"}
local randomMedicine = {"weapon_bandage_sh", "weapon_bigbandage_sh", "weapon_medkit_sh", "weapon_fentanyl", "weapon_morphine", "weapon_adrenaline", "weapon_tourniquet"}
local randomMelees = {"weapon_melee", "weapon_pocketknife"}

function MODE:CanLaunch()
    return true
end

function MODE:Intermission()
    game.CleanUpMap()

    for k, ply in player.Iterator() do
        if ply:Team() == TEAM_SPECTATOR then
            continue
        end
        
        if ApplyAppearance then ApplyAppearance(ply) end
        ply:SetupTeam(0)
    end
    
    net.Start("war_start")
    net.Broadcast()
end

function MODE:CheckAlivePlayers()
    local AlivePlyTbl = {}
    for _, ply in player.Iterator() do
        if not ply:Alive() then continue end
        if ply.organism and ply.organism.incapacitated then continue end
        AlivePlyTbl[#AlivePlyTbl + 1] = ply
    end
    return AlivePlyTbl
end

function MODE:ShouldRoundEnd()
    return (#zb:CheckAlive(true) <= 1)
end

function MODE:RoundStart()
    for _, ply in player.Iterator() do
        if not ply:Alive() then continue end
        
        ply:SetSuppressPickupNotices(true)
        ply.noSound = true
        ply:StripWeapons()
        ply:StripAmmo()
        ply:Give("weapon_hands_sh")

        local inv = ply:GetNetVar("Inventory") or {}
        inv["Weapons"] = inv["Weapons"] or {}
        inv["Weapons"]["hg_sling"] = true
        ply:SetNetVar("Inventory", inv)

        local isGerman = (ply:Team() == 1)
        local weaponPool = isGerman and germanWeapons or americanWeapons
        local armorPool = isGerman and germanArmor or americanArmor

        local loadout = weaponPool[math.random(#weaponPool)]
        local selectedAttachments = istable(loadout.attachments) and table.Random(loadout.attachments) or loadout.attachments

        local gun = ply:Give(loadout.primary)
        if IsValid(gun) then
            ply:GiveAmmo(gun:GetMaxClip1() * loadout.ammo, gun:GetPrimaryAmmoType(), true)
            if hg and hg.AddAttachmentForce then hg.AddAttachmentForce(ply, gun, selectedAttachments) end
        end

        if loadout.secondary then
            local pistol = ply:Give(loadout.secondary)
            if IsValid(pistol) then
                ply:GiveAmmo(pistol:GetMaxClip1() * (loadout.ammo2 or 2), pistol:GetPrimaryAmmoType(), true)
            end
        end

        if hg and hg.AddArmor then hg.AddArmor(ply, armorPool) end
        ply:Give(randomMelees[math.random(#randomMelees)])

        local grenadeCount = math.random(1, 2)
        local usedGrenades = {}
        for i = 1, grenadeCount do
            local grenade = randomGrenades[math.random(#randomGrenades)]
            while usedGrenades[grenade] and i > 1 do
                grenade = randomGrenades[math.random(#randomGrenades)]
            end
            usedGrenades[grenade] = true
            ply:Give(grenade)
        end

        for i = 1, math.random(1, 2) do
            ply:Give(randomMedicine[math.random(#randomMedicine)])
        end

        ply:Give("weapon_walkie_talkie")
        ply:SelectWeapon("weapon_hands_sh")

        if ply.organism then ply.organism.recoilmul = 0.5 end

        timer.Simple(0.1, function() if IsValid(ply) then ply.noSound = false end end)
        ply:SetSuppressPickupNotices(false)
        if zb and zb.GiveRole then
            zb.GiveRole(ply, isGerman and "German Soldier" or "American Soldier", isGerman and Color(120, 120, 120) or Color(50, 120, 50))
        end
        ply:SetNetVar("CurPluv", "pluvboss")
    end
end

function MODE:GiveWeapons() end
function MODE:GiveEquipment() end
function MODE:RoundThink() end

function MODE:PlayerDeath(ply)
    if zb and zb.ROUND_STATE == 1 and ply.GiveSkill then
        ply:GiveSkill(-0.1)
    end
end

function MODE:CanSpawn() end

function MODE:EndRound()
    local playersharm = {}
    if zb and zb.HarmDone then
        for ply, tbl in pairs(zb.HarmDone) do
            for attacker, harm in pairs(tbl) do
                playersharm[attacker] = (playersharm[attacker] or 0) + harm
            end
        end
    end

    local most_violent_player
    local curharm = 0
    for ply, harm in pairs(playersharm) do
        if harm > curharm then
            most_violent_player = ply
            curharm = harm
        end
    end

    timer.Simple(2, function()
        net.Start("war_end")
        local ent = (zb and zb.CheckAlive) and zb:CheckAlive(true)[1] or nil
        
        if IsValid(ent) then
            if ent.GiveExp then ent:GiveExp(math.random(150, 200)) end
            if ent.GiveSkill then ent:GiveSkill(math.Rand(0.2, 0.3)) end
        end

        if IsValid(most_violent_player) then
            if most_violent_player.GiveExp then most_violent_player:GiveExp(math.random(150, 200)) end
            if most_violent_player.GiveSkill then most_violent_player:GiveSkill(math.Rand(0.2, 0.3)) end
        end

        net.WriteEntity(IsValid(ent) and ent:Alive() and ent or NULL)
        net.WriteEntity(IsValid(most_violent_player) and most_violent_player or NULL)
        net.Broadcast()
    end)
end

net.Receive("zcity_request_war_mode", function(len, ply)
    if not IsValid(ply) then return end
    
    local isAllowed = ply:IsAdmin() or ply:IsSuperAdmin() or ply:GetUserGroup() == "owner"

    if not isAllowed then
        ply:ChatPrint("Access denied: Only Admins and Owners can start War mode.")
        return
    end

    if zb and zb.SetMode then
        zb.SetMode("war")
        PrintMessage(HUD_PRINTTALK, "[Admin]" .. ply:Nick() .. " initiated War mode!")
    else
        ply:ChatPrint("Error: zb.SetMode function not found.")
    end
end)