if SERVER then
    AddCSLuaFile("xyphos/sh_xyphoszcity.lua")
    AddCSLuaFile("xyphos/cl_xyphoszcity.lua")
    include("xyphos/sh_xyphoszcity.lua")
    -- include("xyphos/sv_xyphoszcity.lua")
end

if CLIENT then
    include("xyphos/sh_xyphoszcity.lua")
    -- include("xyphos/cl_xyphoszcity.lua")
end