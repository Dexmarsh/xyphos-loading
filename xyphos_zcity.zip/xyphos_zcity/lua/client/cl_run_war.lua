include("sh_war.lua")
include("cl_war.lua")

net.Receive("war_start", function()
    notification.AddLegacy("War Mode Started!", NOTIFY_GENERIC, 5)
    surface.PlaySound("buttons/button14.wav")
end)

net.Receive("war_end", function()
    local winner = net.ReadEntity()
    if IsValid(winner) and winner:IsPlayer() then
        chat.AddText(Color(200, 50, 50), "[War] ", Color(255, 255, 255), "Winner: " .. winner:Nick())
    end
end)