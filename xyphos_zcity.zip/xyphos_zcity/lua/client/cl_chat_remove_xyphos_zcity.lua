hook.Add("HUDShouldDraw", "Xyphos_HideDefaultChat", function(name)
    if name == "CHudChat" then
        return false
    end
end)