hook.Add("HUDPaint", "PlayerESP", function()
	for k, v in pairs(player.GetAll()) do
		local pos = v:GetPos():ToScreen()
		draw.SimpleText(v:Name(), "DermaDefault", pos.x, pos.y, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)