if SERVER then
    hook.Add("PlayerInitialSpawn", "InitMedicalStats", function(ply)
        ply:SetNWFloat("PainLevel", 0)           -- 0 to 100
        ply:SetNWFloat("OxygenLevel", 100)       -- 100 to 0
        ply:SetNWFloat("InfectionLevel", 0)      -- 0 to 100
        ply:SetNWBool("IsUnconscious", false)
        ply:SetNWBool("CyanidePoisoned", false)
        ply:SetNWBool("HasOpenWound", false)
    end)

    hook.Add("Think", "MedicalSystemThink", function()
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) and ply:Alive() then
                
                if ply:GetNWBool("HasOpenWound") then
                    local currentInfection = ply:GetNWFloat("InfectionLevel")
                    local matType = ply:GetMaterialType()
                    
                    if ply:WaterLevel() > 0 or matType == MAT_DIRT or matType == MAT_SLIME then
                        ply:SetNWFloat("InfectionLevel", math.min(100, currentInfection + 0.05))
                    else
                        ply:SetNWFloat("InfectionLevel", math.min(100, currentInfection + 0.01))
                    end
                end

                if ply:GetNWBool("CyanidePoisoned") then
                    local currentPain = ply:GetNWFloat("PainLevel")
                    ply:SetNWFloat("PainLevel", math.min(100, currentPain + 0.1))
                end
            end
        end
    end)

elseif CLIENT then
    
    local function DrawVignette(color, intensity)
        surface.SetDrawColor(color.r, color.g, color.b, math.Clamp(intensity, 0, 255))
        surface.DrawRect(0, 0, ScrW(), ScrH())
    end

    hook.Add("RenderScreenspaceEffects", "XyphosMedicalScreenEffects", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end

    local pain = ply:GetNWFloat("PainLevel", 0) / 100

    local colorTab = {
        [ "$pp_colour_addr" ] = 0,
        [ "$pp_colour_addg" ] = 0,
        [ "$pp_colour_addb" ] = 0,
        [ "$pp_colour_brightness" ] = 0,
        [ "$pp_colour_contrast" ] = 1,
        [ "$pp_colour_colour" ] = 1 - (pain * 0.5),
        [ "$pp_colour_mulr" ] = 0,
        [ "$pp_colour_mulg" ] = 0,
        [ "$pp_colour_mulb" ] = 0
    }

    DrawColorModify(colorTab)

    if pain > 0 then
        DrawMotionBlur(0.1, pain * 0.8, 0.01)
    end

    return true
end)

        if oxygen < 0.5 then
            local oxygenDeficit = (0.5 - oxygen) * 2
            colorTab["$pp_colour_addb"] = oxygenDeficit * 0.2
            colorTab["$pp_colour_brightness"] = -oxygenDeficit * 0.3
        end

        if isCyanide then
            colorTab["$pp_colour_addg"] = 0.15
            colorTab["$pp_colour_colour"] = 0.3
            DrawMotionBlur(0.1, 0.5, 0.05)
        end

        if infection > 0.2 then
            colorTab["$pp_colour_addg"] = infection * 0.08
            colorTab["$pp_colour_colour"] = 1 - (infection * 0.6)
        end

        if isUnconscious or pain >= 0.95 then
            colorTab["$pp_colour_brightness"] = -1.0 -- Pure Black Screen
        end

        DrawColorModify(colorTab)
    end)

    hook.Add("HUDPaint", "DrawMedicalStatusHUD", function()
        local ply = LocalPlayer()
        if not IsValid(ply) or not ply:Alive() then return end

        local infection = ply:GetNWFloat("InfectionLevel", 0)
        local pain = ply:GetNWFloat("PainLevel", 0)

        if infection > 25 then
            draw.SimpleText("", "DermaDefaultBold", 20, ScrH() - 60, Color(200, 180, 50), TEXT_ALIGN_LEFT)
        end
        
        if pain > 75 then
            draw.SimpleText("", "DermaDefaultBold", 20, ScrH() - 40, Color(220, 50, 50), TEXT_ALIGN_LEFT)
        end
    end)
end