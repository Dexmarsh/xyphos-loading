-- Remove ZCity / Homigrad Chat & Dialogue Overrides
hook.Add("InitPostEntity", "XyphosOverrideZCityDialogue", function()
    hook.Remove("HUDShouldDraw", "ZChat")
    hook.Remove("OnPlayerChat", "ZChatDead")
    hook.Remove("HG_OnPlayerChat", "TextModificationBasedOnStuff")
    hook.Remove("HUDPaint", "afflictionlist")
    hook.Remove("HUDPaint", "EntHints")
end)

surface.CreateFont("Xyphos_DialogueFont", {
    font = "Roboto",
    size = 22,
    weight = 700,
    shadow = true,
})

local currentDialogue = ""
local dialogueEndTime = 0
local dialogueColor = Color(255, 255, 255)

local dialogueLines = {
    [HITGROUP_HEAD] = {
        "My head is pounding...",
        "My Vision's going blurry!",
        "Gah! My Ears are ringing!"
    },
    [HITGROUP_CHEST] = {
        "I Can't... breathe...",
        "I Took one right in the ribs!",
        "Im Gasping for air..."
    },
    [HITGROUP_STOMACH] = {
        "Agh! Right in the gut!",
        "I'm gonna throw up...",
        "I Got Internal damage... dammit!"
    },
    [HITGROUP_LEFTARM] = {
        "My Dumbass arm's completely useless!",
        "Gah! Fuck, Left arm took a hit!",
        "I Can barely hold my weapon..."
    },
    [HITGROUP_RIGHTARM] = {
        "My armmm!",
        "Agh! My right hand's numb!",
        "Dammit, my arm!"
    },
    [HITGROUP_LEFTLEG] = {
        "My leg! I can't run!",
        "Gah... limping here!",
        "It Took out my left knee!"
    },
    [HITGROUP_RIGHTLEG] = {
        "My Fucking Right leg is wrecked!",
        "I can't put pressure on this leg!",
        "Agh! Fuckk, My Leg's giving out!"
    },
    -- Default fallback for generic damage
    ["Generic"] = {
        "Dammit, that hurt!",
        "Fucking Hell!",
        "AHH FUCK!"
    }
}

net.Receive("XyphosTriggerDialogue", function()
    local hp = net.ReadInt(16)
    local hitgroup = net.ReadInt(8)

    local lines = dialogueLines[hitgroup] or dialogueLines["Generic"]
    currentDialogue = lines[math.random(#lines)]

    -- Color shifts based on health severity
    if hp < 30 then
        dialogueColor = Color(230, 60, 60)
    elseif hp < 60 then
        dialogueColor = Color(240, 180, 50)
    else
        dialogueColor = Color(220, 220, 220)
    end

    dialogueEndTime = CurTime() + 3.5
end)

hook.Add("HUDPaint", "XyphosDrawDialogueHUD", function()
    if CurTime() < dialogueEndTime and currentDialogue ~= "" then
        local alpha = math.Clamp((dialogueEndTime - CurTime()) * 255, 0, 255)
        local drawColor = Color(dialogueColor.r, dialogueColor.g, dialogueColor.b, alpha)

        draw.SimpleText("\"" .. currentDialogue .. "\"", "Xyphos_DialogueFont", ScrW() / 2, ScrH() * 0.8, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end)