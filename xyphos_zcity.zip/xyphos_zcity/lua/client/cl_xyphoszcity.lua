include("autorun/sh_xyphoszcity.lua")

-- Custom Fonts
surface.CreateFont("IG_Title", {
	font = "Roboto",
	size = 22,
	weight = 800,
})

surface.CreateFont("IG_Header", {
	font = "Roboto",
	size = 14,
	weight = 700,
})

surface.CreateFont("IG_Name", {
	font = "Roboto",
	size = 16,
	weight = 700,
})

surface.CreateFont("IG_Sub", {
	font = "Roboto",
	size = 11,
	weight = 600,
})

local function ToggleScoreboard(toggle)
	if toggle then 
		local scrw, scrh = ScrW(), ScrH()
		
		XyphosScoreboard = vgui.Create("DFrame")
		XyphosScoreboard:SetTitle("")
		XyphosScoreboard:SetSize(scrw * 0.55, scrh * 0.65)
		XyphosScoreboard:Center()
		XyphosScoreboard:MakePopup()
		XyphosScoreboard:ShowCloseButton(false)
		XyphosScoreboard:SetDraggable(false)

		XyphosScoreboard.Paint = function(self, w, h)
			-- Main Dark Background with Accent Border
			surface.SetDrawColor(18, 18, 22, 240)
			surface.DrawRect(0, 0, w, h)

			surface.SetDrawColor(255, 185, 0, 255)
			surface.DrawRect(0, 0, w, 3)

			draw.SimpleText("XYPHOS CITY", "IG_Title", 15, 15, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText("PLAYERS: " .. #player.GetAll() .. " / " .. game.MaxPlayers(), "IG_Sub", 15, 40, Color(160, 160, 160), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

			draw.SimpleText("PLAYER", "IG_Header", 55, 62, Color(120, 120, 130), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("PING", "IG_Header", w - 170, 62, Color(120, 120, 130), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("ACTION", "IG_Header", w - 60, 62, Color(120, 120, 130), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			surface.SetDrawColor(255, 255, 255, 10)
			surface.DrawLine(15, 75, w - 15, 75)
		end

		local scroll = vgui.Create("DScrollPanel", XyphosScoreboard)
		scroll:SetPos(15, 80)
		scroll:SetSize(XyphosScoreboard:GetWide() - 30, XyphosScoreboard:GetTall() - 90)

		local sbar = scroll:GetVBar()
		sbar:SetWide(6)
		function sbar:Paint(w, h) end
		function sbar.btnGrip:Paint(w, h)
			draw.RoundedBox(3, 0, 0, w, h, Color(255, 185, 0, 150))
		end
		function sbar.btnUp:Paint() end
		function sbar.btnDown:Paint() end

		local ypos = 0
		for k, v in ipairs(player.GetAll()) do
			if IsValid(v) then
				local playerPanel = vgui.Create("DPanel", scroll)
				playerPanel:SetPos(0, ypos)
				playerPanel:SetSize(scroll:GetWide(), 46)
				playerPanel.TargetPlayer = v

				playerPanel.Paint = function(self, w, h)
					local ply = self.TargetPlayer
					if IsValid(ply) then
						-- Card Row Background
						surface.SetDrawColor(28, 29, 36, 220)
						surface.DrawRect(0, 0, w, h)

						local rankColor = ply:IsSuperAdmin() and Color(255, 185, 0) or Color(80, 80, 90)
						surface.SetDrawColor(rankColor)
						surface.DrawRect(0, 0, 5, h)

						draw.SimpleText(ply:Name(), "IG_Name", 50, ply:IsSuperAdmin() and 12 or h / 2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

						if ply:IsSuperAdmin() then
							draw.SimpleText("SUPERADMIN", "IG_Sub", 50, 31, Color(255, 185, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						end

						draw.SimpleText(ply:Ping() .. "ms", "IG_Header", w - 155, h / 2, Color(180, 180, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end

				local avatar = vgui.Create("AvatarImage", playerPanel)
				avatar:SetSize(32, 32)
				avatar:SetPos(10, 7)
				avatar:SetPlayer(v, 64)

				if v ~= LocalPlayer() then
					local muteBtn = vgui.Create("DButton", playerPanel)
					muteBtn:SetSize(80, 26)
					muteBtn:SetPos(playerPanel:GetWide() - 95, 10)
					muteBtn:SetText("")
					muteBtn.TargetPlayer = v

					muteBtn.Paint = function(self, w, h)
						local ply = self.TargetPlayer
						if IsValid(ply) then
							local isMuted = ply:IsMuted()
							local bgCol = isMuted and Color(200, 50, 50, 200) or Color(45, 48, 58, 255)
							local textCol = isMuted and color_white or Color(180, 180, 180)

							surface.SetDrawColor(bgCol)
							surface.DrawRect(0, 0, w, h)

							draw.SimpleText(isMuted and "MUTED" or "MUTE", "IG_Sub", w / 2, h / 2, textCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
					end

					muteBtn.DoClick = function(self)
						local ply = self.TargetPlayer
						if IsValid(ply) then
							ply:SetMuted(not ply:IsMuted())
						end
					end
				end

				ypos = ypos + 50
			end
		end
	else
		if IsValid(XyphosScoreboard) then
			XyphosScoreboard:Remove()
		end
	end
end

hook.Add("ScoreboardShow", "XyphosOpenScoreboard", function()
	ToggleScoreboard(true)
	return false
end)

hook.Add("ScoreboardHide", "XyphosHideScoreboard", function()
	ToggleScoreboard(false)
end)